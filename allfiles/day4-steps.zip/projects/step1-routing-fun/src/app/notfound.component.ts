import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-notfound',
  template: `
      <h2>404 | Requested page not found component</h2>
  `,
  styles: [
  ]
})
export class NotfoundComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
