import { Component } from "@angular/core";

@Component({
    selector : 'app-citi',
    template : `
        <h2>Hello from citi component</h2>
    `
})
export class CitiComp{

}