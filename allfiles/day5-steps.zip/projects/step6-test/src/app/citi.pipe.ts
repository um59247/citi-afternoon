import { Pipe } from "@angular/core";

@Pipe({
    name : 'citi'
})
export class CitiPipe{
    transform(...args:any){
        return args[1]+" "+args[0]
    }
}