import { Component, EventEmitter, Input, Output } from "@angular/core";

@Component({
    selector : 'app-child',
    template : `
    <h1>Child Component</h1>
    <ng-content select="p.box"></ng-content>
    <ng-content select="button"></ng-content>
    <ng-content select="ul"></ng-content>
    <ng-content></ng-content>
    <h3>Message : {{ message }}</h3>
    <button (click)="changeCase()">Change Case</button>
    <input #ti2 type="text">
    <input #ti3 type="password">
    <button (click)="dispatchCompEvent(ti2.value,ti3.value)">Dispatch Comp Event </button>
    `
})
export class ChildComp{
   @Input('publicmessage') message = 'default message';
   @Output() compEvent:EventEmitter<any> = new EventEmitter();

   changeCase(){
       this.message = this.message.toUpperCase();
   }
   dispatchCompEvent(uname:string, upass:string){
        this.compEvent.emit({ uname, upass });
   }
}