import { Component } from "@angular/core";

@Component({
    selector : 'app-third',
    template : `
    <h1>Third Component</h1>
    <hr>
    <h3>{{ title }}</h3>
    <input #ti1 [value]="title" (input)="title = ti1.value">
    <input [(ngModel)]="title">
    `
})
export class ThirdComp{
    title : string = "Default Title";
}