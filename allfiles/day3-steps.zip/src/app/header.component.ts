import { Component, Input, OnInit } from '@angular/core';
import { HeroService } from './hero.service';

@Component({
  selector: 'app-header',
  template: `
  <h2>{{ appversion }}</h2>
  <app-child></app-child>
  <app-child></app-child>
  <app-child></app-child>
      <ul class="nav justify-content-center">    
         <li  *ngFor="let hero of heroes" class="nav-item">
          <a class="nav-link" href="#">{{ hero.title }}</a>
        </li>
     </ul>
  `,
  styles: [
  ]
})
export class HeaderComponent {
  heroes:any;
  appversion:any;
  // hs:HeroService = new HeroService();

  constructor(private hs:HeroService){
    this.heroes = this.hs.getHero();
    this.appversion = this.hs.getVersion();
  }
}
