import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <app-child></app-child>
  `,
  styles: []
})
export class AppComponent {
  title = 'step1-directives-pipes';
}
