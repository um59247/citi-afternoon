import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
   <!--  
   <ul>
      <li><a href="">Home</a></li>
      <li><a href="ironman">Ironman</a></li>
      <li><a href="hulk">Hulk</a></li>
      <li><a href="blackwidow">Black Widow</a></li>
      <li><a href="thor">Thor</a></li>
      <li><a href="vision">Vision</a></li>
    </ul> 
  -->
  <div class="container">
  <ul class="nav justify-content-center">
    <li  class="nav-item"> <a [routerLink]="['']"           routerLinkActive="player" [routerLinkActiveOptions]="{ exact: true }" class="nav-link">Home</a> </li>
    <li  class="nav-item"> <a [routerLink]="['ironman']"    routerLinkActive="player" class="nav-link" >Ironman</a></li>
    <li  class="nav-item"> <a [routerLink]="['hulk',power]"       routerLinkActive="player" class="nav-link" >Hulk</a></li>
    <li  class="nav-item"> <a [routerLink]="['blackwidow']" routerLinkActive="player" class="nav-link" >Black Widow</a></li>
    <li  class="nav-item"> <a [routerLink]="['thor']"       routerLinkActive="player" class="nav-link" >Thor</a></li>
    <li  class="nav-item"> <a [routerLink]="['vision']"     routerLinkActive="player" class="nav-link" >Vision</a></li>
  </ul>
  <input type="range" [(ngModel)]="power">Power is {{ power }}
   <hr>
   <router-outlet></router-outlet>
  </div>
  `,
  styles: [`
  .player{
    background-color : crimson;
    color : papayawhip;
  }
  `]
})
export class AppComponent {
  power = 0;
  title = 'step1-routing-fun';
}
