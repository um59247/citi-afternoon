import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { CitiDirective } from './citi.directive';

@NgModule({
  // components, directives, pipes
  declarations: [ AppComponent, CitiDirective ],
  // additional modules
  imports: [ BrowserModule ],
  // services
  providers: [],
  // attach main component
  bootstrap: [AppComponent]
})
export class AppModule { }
