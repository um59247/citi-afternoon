import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
   <h1>Custom Directive / Pipe / Module / Component </h1>
<!--     
    <citi>
     <p>Paragraph 1</p>
    </citi> 
-->
<!--  <p class="citi">Paragraph 3</p> -->   
<!--    <p citi="red">Paragraph 1</p>
   <p citi="aqua">Paragraph 2</p>
   <p citi="orange">Paragraph 4</p>
   <p citi="green">Paragraph 5</p>
   <p citi="blue">Paragraph 6</p>
   <p citi="grey">Paragraph 7</p>  -->
   <p citi="button">Paragraph 1</p>
   <p citi="h1">Paragraph 1</p>
  `,
  styles: []
})
export class AppComponent {
  title = 'step1-custom';
}

/*
*ngFor
*ngIf
ngSwitch
router-outlet
ng-content
[(ngModel)]
*/