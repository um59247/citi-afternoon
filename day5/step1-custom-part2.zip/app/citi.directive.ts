import { Directive, ElementRef, Input } from "@angular/core";


// tag directive citi
// attribute directive [citi]
// class directive .citi

@Directive({
    selector : '[citi]'
})
export class CitiDirective{
   @Input() citi:any;

    constructor(private elRef:ElementRef){}
   /*  ngOnInit(){
        // this.elRef.nativeElement.innerHTML = "Hello From Citi "+this.citi;
        this.elRef.nativeElement.style.backgroundColor = this.citi;
    } */

   /*  
    ngOnInit(){
        this.elRef.nativeElement.addEventListener("click", this.clickHandler);
    } 

    clickHandler(evt:any){
        // alert("you clicked me");
        let elm = evt.target
        let color = elm.getAttribute("citi");
        elm.style.backgroundColor = color;
    } */

    ngOnInit(){
        let elmtype = this.citi;
        let content = this.elRef.nativeElement.innerHTML;
        this.elRef.nativeElement.outerHTML = `<${elmtype}>${content}</${elmtype}>`
    } 
}