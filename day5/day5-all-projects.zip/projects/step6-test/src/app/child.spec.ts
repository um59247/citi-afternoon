import { TestBed } from "@angular/core/testing";
import { HttpClientTestingModule, HttpTestingController } from "@angular/common/http/testing";

describe("testing async",()=>{
    beforeEach(()=>{
        TestBed.configureTestingModule({
            imports : [HttpClientTestingModule]
        })
    })
    it("place holder",()=>{
        console.log("child test")
    })
})