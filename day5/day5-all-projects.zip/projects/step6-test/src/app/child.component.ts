import { Component } from "@angular/core";

@Component({
    selector : "app-child",
    template : `
        <h1>Child Component</h1>
        <hr>
        
    `
})
export class ChildComp{

}