import { CitiPipe } from "./citi.pipe";

describe("Test CitiPipe",()=>{
    let citipipe:CitiPipe;

    beforeEach(()=>{
        console.log("beforeEach from ischoolpipe was called");
        citipipe = new CitiPipe();
    });

    it("should check if the citipipe is defined",()=>{
        expect(citipipe).toBeDefined();
    });
    it("should check if the citipipe working",()=>{
        expect(citipipe.transform('vijay','hi')).toBe('hi vijay');
    });

})