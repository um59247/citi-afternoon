import { Component } from "@angular/core";
import { HeroService } from "./hero.service";

@Component({
    selector : 'app-child',
    template : `
    <h3>Child Component</h3>
    <h4>Version is : {{ version }}</h4>
    `
})
export class ChildComp{
    version:any

    constructor(private hs:HeroService){}
    
    ngOnInit(){
        this.version = this.hs.getVersion();
    }
}