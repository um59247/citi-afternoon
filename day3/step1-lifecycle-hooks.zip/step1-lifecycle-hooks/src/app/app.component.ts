import { Component, ElementRef, QueryList, ViewChild, ViewChildren } from '@angular/core';
import { ChildComponent } from './child.component';

@Component({
  selector: 'app-root',
  template: `
  <h1>Lifecycle Hooks</h1>
  <button (click)="increasePower()">Increase Power</button>
  <button (click)="decreasePower()">Decrease Power</button>
  <hr>
  <button (click)="toggleHideShow()">Show / Hide</button>
  <!-- <app-child #boxer *ngIf="show"></app-child> -->
  <app-child></app-child>
  <app-child></app-child>
  <app-child></app-child>
  <app-child></app-child>
  `,
  styles: []
})
export class AppComponent {
  title = 'step1-lifecycle-hooks';
  show = true;
  appPower = 0;
  compList:any;

  // @ViewChild(ChildComponent) childComp:any;
    @ViewChildren(ChildComponent) childComp!:QueryList<ElementRef>;


  constructor() { 
    console.log("AppComponent's constructor was called");
  }
  
  ngOnInit(): void {
    console.log("AppComponent's ngOnInit was called");
  }
  ngOnChanges(): void {
    console.log("AppComponent's ngOnChanges was called");
  }
  ngDoCheck(): void {
    console.log("AppComponent's ngDoCheck was called");
  }
  ngAfterViewInit(): void {
    console.log(this.childComp);
    this.compList = this.childComp.toArray();
    console.log(this.compList[0].power);
    console.log("AppComponent's ngAfterViewInit was called");
  }
  ngAfterViewChecked(): void {
    console.log("AppComponent's ngAfterViewChecked was called");
  }
  ngAfterContentInit(): void {
    console.log("AppComponent's ngAfterContentInit was called");
  }
  ngAfterContentChecked(): void {
    console.log("AppComponent's ngAfterContentChecked was called");
  }
  ngOnDestroy(): void {
    console.log("AppComponent's ngOnDestroy was called");
  }

  toggleHideShow(){
    this.show = !this.show;
  }

  increasePower(){
    // this.appPower++;
    // this.childComp.increasePower();
    this.compList[1].increasePower();
  }
  decreasePower(){
    // this.appPower--;
    // this.childComp.decreasePower();
    this.compList[1].decreasePower();
  }
}
