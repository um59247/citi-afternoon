import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reactive-form',
  template: `
     <h2>Reactive Form</h2>
  `,
  styles: [
  ]
})
export class ReactiveFormComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
